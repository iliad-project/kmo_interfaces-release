var page_user_guide_dev_info =
[
    [ "Obtaining special information", "page_user_guide_dev_info_special.html", null ],
    [ "Obtaining Status Information", "page_user_guide_dev_info_status.html", null ]
];