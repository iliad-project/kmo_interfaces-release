var searchData=
[
  ['bit_20rate_20examples',['Bit Rate Examples',['../page_code_snippets_bit_rate.html',1,'page_code_snippets']]],
  ['bit_20rate_20and_20other_20bus_20parameters',['Bit Rate and Other Bus Parameters',['../page_user_guide_init_bit_rate.html',1,'page_user_guide_init']]],
  ['bit_20rate_20constants',['Bit Rate Constants',['../page_user_guide_misc_bitrate.html',1,'page_user_guide_misc']]],
  ['bus_20on_20_2f_20bus_20off',['Bus On / Bus Off',['../page_user_guide_send_recv_bus_on_off.html',1,'page_user_guide_send_recv']]]
];
