var searchData=
[
  ['kvadbprotocolproperties',['KvaDbProtocolProperties',['../struct_kva_db_protocol_properties.html',1,'']]],
  ['kvtimedomaindata_5fs',['kvTimeDomainData_s',['../structkv_time_domain_data__s.html',1,'']]]
];
