var searchData=
[
  ['version',['version',['../struct_j1587_message_info.html#a278ac8112eb4d891fdffa2a26fb4de69',1,'J1587MessageInfo']]]
];
