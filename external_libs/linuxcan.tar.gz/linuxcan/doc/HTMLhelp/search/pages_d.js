var searchData=
[
  ['reading_20messages',['Reading Messages',['../page_user_guide_send_recv_reading.html',1,'page_user_guide_send_recv']]]
];
