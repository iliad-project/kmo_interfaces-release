var searchData=
[
  ['bitrate',['bitrate',['../struct_lin_message_info.html#ae1500e00270cc662f39a27c2f2d23962',1,'LinMessageInfo::bitrate()'],['../struct_j1587_message_info.html#a34ee9ae488c5e76706950ff6b8ae6c2d',1,'J1587MessageInfo::bitrate()']]],
  ['busload',['busLoad',['../structcan_bus_statistics__s.html#a10d3e5def5be80618a372a441eaadc2f',1,'canBusStatistics_s']]],
  ['bytetime',['byteTime',['../struct_lin_message_info.html#a49b9c16add79f98b4f26894ae8f44356',1,'LinMessageInfo']]]
];
