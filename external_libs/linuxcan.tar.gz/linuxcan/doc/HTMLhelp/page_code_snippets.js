var page_code_snippets =
[
    [ "Code Examples", "page_code_snippets_examples.html", null ],
    [ "Bit Rate Examples", "page_code_snippets_bit_rate.html", null ]
];