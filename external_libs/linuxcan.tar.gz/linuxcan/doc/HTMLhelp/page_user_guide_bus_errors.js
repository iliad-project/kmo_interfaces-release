var page_user_guide_bus_errors =
[
    [ "Handling Bus Errors", "page_user_guide_bus_errors_error_frames.html", null ],
    [ "SJA1000 Error Codes", "page_user_guide_bus_errors_sja1000_error_codes.html", null ]
];