var struct_j1587_message_info =
[
    [ "version", "struct_j1587_message_info.html#a278ac8112eb4d891fdffa2a26fb4de69", null ],
    [ "flags", "struct_j1587_message_info.html#a78ac89a4a0f57ffa7c2ecf31749aa390", null ],
    [ "frameDelay", "struct_j1587_message_info.html#a55f2df81911751a16eb20d7a0125ca9c", null ],
    [ "checkSum", "struct_j1587_message_info.html#a0890e48334b4123d76276b8341d3d82c", null ],
    [ "retries", "struct_j1587_message_info.html#a89d4147f125445dabe7483285cf75e2d", null ],
    [ "timestamp", "struct_j1587_message_info.html#acba7776dcc1861edfe0e9c5736de4df8", null ],
    [ "frameLength", "struct_j1587_message_info.html#aedcbabfa0a2b5302ee5b5000812096f3", null ],
    [ "bitrate", "struct_j1587_message_info.html#a34ee9ae488c5e76706950ff6b8ae6c2d", null ],
    [ "reserved", "struct_j1587_message_info.html#a3415ebf9c5050a50fa3ae127df65e763", null ]
];