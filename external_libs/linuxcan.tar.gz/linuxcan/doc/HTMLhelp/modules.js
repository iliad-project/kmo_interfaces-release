var modules =
[
    [ "General", "group___general.html", "group___general" ],
    [ "CAN", "group___c_a_n.html", "group___c_a_n" ],
    [ "Object buffers", "group___object_buffers.html", "group___object_buffers" ],
    [ "Time Domain Handling", "group___time_domain_handling.html", "group___time_domain_handling" ],
    [ "Named Parameter Settings", "group___named_parameter_settings.html", "group___named_parameter_settings" ],
    [ "t-script", "group__t_script.html", "group__t_script" ],
    [ "Obsolete API Reference", "group___obsolete.html", "group___obsolete" ],
    [ "CAN Database", "group___c_a_n_d_b.html", "group___c_a_n_d_b" ],
    [ "LIN", "group___l_i_n.html", "group___l_i_n" ],
    [ "J1587", "group___j1587.html", "group___j1587" ]
];