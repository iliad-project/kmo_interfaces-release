var structtag_can_h_w_descr =
[
    [ "circuitType", "structtag_can_h_w_descr.html#ab589b62ba66057923f4dac909e0f3e78", null ],
    [ "cardType", "structtag_can_h_w_descr.html#a359605673676d6f622b7b0e3e7c52982", null ],
    [ "channel", "structtag_can_h_w_descr.html#adf7dff2c57c0da9a4a2b70e3e815be31", null ]
];