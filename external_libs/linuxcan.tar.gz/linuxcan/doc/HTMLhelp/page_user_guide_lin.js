var page_user_guide_lin =
[
    [ "Using the LIN Bus", "page_user_guide_lin_intro.html", null ],
    [ "Accessing the Databases", "page_user_guide_lin_candb.html", null ]
];