var structtag_can_s_w_descr =
[
    [ "rxBufSize", "structtag_can_s_w_descr.html#a22031cf318e44e0c0d51be474623e6f5", null ],
    [ "txBufSize", "structtag_can_s_w_descr.html#a4f409383284eb558a8b4c97e46155799", null ],
    [ "alloc", "structtag_can_s_w_descr.html#a4709e7f10fd7a579fa7e103f3e0de491", null ],
    [ "deAlloc", "structtag_can_s_w_descr.html#a02d13eb86e10f0ce10d4f87ea08093a1", null ]
];